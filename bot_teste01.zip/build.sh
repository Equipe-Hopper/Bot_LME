#!/bin/bash

zip -r "bot_teste01.zip" * -x "bot_teste01.zip"